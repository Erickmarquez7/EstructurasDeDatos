Bernal Márquez Erick.       317042522

Cuesta un poco de trabajo entender al 100% la recursividad, pero una vez que entiendes la recursividad, entiendes la recursividad.

Para ejecutar  la práctica se usan los siguientes comandos:

1. ant build

2. ant jar

3. ant run

Para limpiar archivos:

4. ant clean

 

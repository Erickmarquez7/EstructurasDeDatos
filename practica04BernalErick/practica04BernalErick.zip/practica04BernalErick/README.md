Erick Bernal Márquez        317042522
Practica 4                  Nov/2020

fue dificil :'v

Para ejecutar  la práctica se usan los siguientes comandos:

1. ant build

2. ant jar

3. ant run

Para limpiar archivos:

4. ant clean

 
